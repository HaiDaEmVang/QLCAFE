/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quanlysinhvien.Test;

import java.io.BufferedReader;
import quanlysinhvien.Views.QLTS_Views;



/**
 *
 * @author Lê H
 */
public class QLTS_Test {
    public static void main(String[] args) {
        new QLTS_Views().setVisible(true);
    }
}
